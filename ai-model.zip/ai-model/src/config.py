FEATURES = [
    "CPU-Usage-Percentage",
    "Memory-Usage-Percentage",
    "Disk-Usage-Percentage"
]

MODEL_PATH = "models/isolation_forest.pkl"
DATA_PATH = "data/system_performance_metrics.csv"
