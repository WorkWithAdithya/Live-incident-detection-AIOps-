LOG_INTERVAL_SECONDS = 5
OUTPUT_FILE = "output/system_logs.xlsx"